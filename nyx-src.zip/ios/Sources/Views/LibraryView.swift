import QuickLook
import SwiftUI

/// Onglet Bibliothèque : Fichiers, Coffre, playlists et tous les téléchargements.
struct LibraryView: View {
    @EnvironmentObject var model: AppModel
    @AppStorage("libraryFilter") private var filter = "all"
    @State private var query = ""
    @State private var picking: Track?
    @State private var deleting: Track?
    @State private var creating = false
    @State private var newName = ""
    @State private var confirmClear = false
    @State private var previewItems: [URL] = []
    @State private var previewURL: URL?

    private var shown: [Track] {
        var list = model.tracks
        switch filter {
        case "video": list = list.filter { $0.kind != "audio" }
        case "audio": list = list.filter { $0.kind == "audio" }
        default: break
        }
        let text = query.trimmingCharacters(in: .whitespaces).lowercased()
        if !text.isEmpty {
            list = list.filter { $0.title.lowercased().contains(text) || $0.uploader.lowercased().contains(text) }
        }
        return list
    }

    var body: some View {
        NavigationStack(path: $model.libraryPath) {
            List {
                if let error = model.engineError {
                    Section {
                        EngineErrorCard(message: error)
                    }
                }
                Section {
                    HStack(spacing: 12) {
                        Tile(icon: "folder.fill", title: L("Fichiers")) {
                            model.libraryPath = [.files(PythonEngine.documentsURL.path)]
                        }
                        Tile(icon: "lock.fill", title: L("Coffre"), tint: .red) {
                            model.openVault()
                        }
                    }
                    .listRowInsets(EdgeInsets(top: 4, leading: 16, bottom: 8, trailing: 16))
                    .listRowBackground(Color.clear)
                    .listRowSeparator(.hidden)
                }

                Section {
                    NavigationLink(value: LibraryRoute.favorites) {
                        playlistRow(L("Favoris"), icon: "heart.fill", color: .pink, count: model.favoriteTracks.count)
                    }
                    ForEach(model.playlists) { playlist in
                        NavigationLink(value: LibraryRoute.playlist(playlist.id)) {
                            playlistRow(playlist.name, icon: "rectangle.stack.fill", color: .brand,
                                        count: playlist.items.count)
                        }
                    }
                    Button {
                        newName = ""
                        creating = true
                    } label: {
                        Label(L("Nouvelle playlist"), systemImage: "plus.circle.fill")
                            .foregroundColor(.brand)
                    }
                } header: {
                    Text(L("Playlists"))
                }

                Section {
                    Picker("", selection: $filter) {
                        Text(L("Tout")).tag("all")
                        Text(L("Vidéos")).tag("video")
                        Text(L("Audio")).tag("audio")
                    }
                    .pickerStyle(.segmented)
                    .listRowSeparator(.hidden)

                    let list = shown
                    if list.isEmpty {
                        if !model.libraryLoaded && model.engineError == nil {
                            HStack {
                                Spacer()
                                ProgressView()
                                Spacer()
                            }
                            .padding(.vertical, 30)
                            .listRowSeparator(.hidden)
                        } else if !query.isEmpty {
                            EmptyState(icon: "magnifyingglass", title: L("Aucun résultat"),
                                       subtitle: L("Essayez avec d'autres mots."))
                                .listRowSeparator(.hidden)
                        } else {
                            EmptyState(icon: "arrow.down.circle", title: L("Vos téléchargements apparaîtront ici."),
                                       subtitle: L("Collez un lien dans l'onglet Télécharger, ou ouvrez une vidéo dans le Navigateur."))
                                .listRowSeparator(.hidden)
                        }
                    } else {
                        ForEach(Array(list.enumerated()), id: \.element.id) { index, track in
                            TrackRow(track: track, onTap: { open(track, in: list, at: index) }) {
                                TrackActions(track: track, picking: $picking, deleting: $deleting)
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button(role: .destructive) {
                                    deleting = track
                                } label: {
                                    Label(L("Supprimer"), systemImage: "trash")
                                }
                            }
                            .swipeActions(edge: .leading) {
                                Button {
                                    model.toggleFavorite(track)
                                } label: {
                                    Label(L("Favori"), systemImage: model.isFavorite(track) ? "heart.slash" : "heart")
                                }
                                .tint(.pink)
                            }
                            .contextMenu {
                                TrackActions(track: track, picking: $picking, deleting: $deleting)
                            }
                        }
                    }
                } header: {
                    Text(L("Téléchargements"))
                }
            }
            .listStyle(.plain)
            .navigationTitle(L("Bibliothèque"))
            .searchable(text: $query, prompt: L("Rechercher"))
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        newName = ""
                        creating = true
                    } label: {
                        CircleIcon(systemName: "plus")
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button {
                            model.openInFiles()
                        } label: {
                            Label(L("Ouvrir dans Fichiers"), systemImage: "folder")
                        }
                        Button(role: .destructive) {
                            confirmClear = true
                        } label: {
                            Label(L("Effacer l'historique"), systemImage: "trash")
                        }
                    } label: {
                        CircleIcon(systemName: "ellipsis")
                    }
                }
            }
            .refreshable {
                await MainActor.run { model.refreshLibrary() }
            }
            .navigationDestination(for: LibraryRoute.self) { route in
                switch route {
                case .files(let path):
                    FilesView(path: path)
                default:
                    CollectionView(route: route)
                }
            }
            .alert(L("Nouvelle playlist"), isPresented: $creating) {
                TextField(L("Nom de la playlist"), text: $newName)
                Button(L("Annuler"), role: .cancel) {}
                Button(L("Créer")) {
                    model.createPlaylist(newName) { uid in
                        model.libraryPath = [.playlist(uid)]
                    }
                }
            }
            .confirmationDialog(L("Effacer l'historique"), isPresented: $confirmClear, titleVisibility: .visible) {
                Button(L("Effacer l'historique"), role: .destructive) { model.clearHistory() }
                Button(L("Annuler"), role: .cancel) {}
            } message: {
                Text(L("La liste des téléchargements sera vidée. Les fichiers restent dans l'app Fichiers, les playlists et le Coffre ne changent pas."))
            }
            .trackSheets(picking: $picking, deleting: $deleting)
            .quickLookPreview($previewURL, in: previewItems)
        }
    }

    private func open(_ track: Track, in list: [Track], at index: Int) {
        if track.isFolder {
            let photos = track.photoURLs
            guard let first = photos.first else {
                model.show(L("Fichier introuvable (supprimé ou déplacé)."), .warn)
                return
            }
            previewItems = photos
            previewURL = first
        } else {
            model.play(list, start: index)
        }
    }

    private func playlistRow(_ title: String, icon: String, color: Color, count: Int) -> some View {
        HStack(spacing: 12) {
            SettingsIcon(systemName: icon, color: color)
            Text(title)
            Spacer()
            Text("\(count)")
                .foregroundColor(.secondary)
        }
    }
}

/// Favoris, Coffre ou une playlist.
struct CollectionView: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.dismiss) private var dismiss
    let route: LibraryRoute
    @State private var picking: Track?
    @State private var deleting: Track?
    @State private var renaming = false
    @State private var newName = ""
    @State private var confirmDelete = false
    @State private var previewItems: [URL] = []
    @State private var previewURL: URL?

    private var playlist: Playlist? {
        if case .playlist(let id) = route { return model.playlist(id) }
        return nil
    }

    private var isVault: Bool {
        if case .vault = route { return true }
        return false
    }

    private var title: String {
        switch route {
        case .favorites: return L("Favoris")
        case .vault: return L("Coffre")
        default: return playlist?.name ?? L("Playlist")
        }
    }

    private var tracks: [Track] {
        switch route {
        case .favorites: return model.favoriteTracks
        case .vault: return model.vaultUnlocked ? model.vault : []
        default: return playlist?.items ?? []
        }
    }

    var body: some View {
        List {
            if isVault && !model.vaultUnlocked {
                VStack(spacing: 16) {
                    EmptyState(icon: "lock.fill", title: L("Coffre verrouillé"),
                               subtitle: L("Identifiez-vous avec Face ID pour voir vos fichiers privés."))
                    Button(L("Déverrouiller")) {
                        model.unlockVault {}
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .padding(.horizontal, 50)
                }
                .listRowSeparator(.hidden)
                .listRowBackground(Color.clear)
            } else {
                if isVault {
                    Text(L("Les fichiers du Coffre sont cachés de la Bibliothèque et de l'app Fichiers. Le Coffre se reverrouille dès que vous le quittez."))
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)
                        .listRowSeparator(.hidden)
                }
                let list = tracks
                if !list.isEmpty {
                    HStack(spacing: 12) {
                        Button {
                            model.play(list, start: 0)
                        } label: {
                            Label(L("Tout lire"), systemImage: "play.fill")
                        }
                        .buttonStyle(PrimaryButtonStyle())
                        Button {
                            let mixed = list.filter { !$0.isFolder }.shuffled()
                            if !mixed.isEmpty { model.play(mixed, start: 0) }
                        } label: {
                            Label(L("Aléatoire"), systemImage: "shuffle")
                        }
                        .buttonStyle(PrimaryButtonStyle(filled: false))
                    }
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                }
                if list.isEmpty {
                    EmptyState(icon: isVault ? "lock" : "rectangle.stack", title: L("Aucun élément"), subtitle: emptyText)
                        .listRowSeparator(.hidden)
                } else {
                    ForEach(Array(list.enumerated()), id: \.element.id) { index, track in
                        TrackRow(track: track, onTap: { open(track, in: list, at: index) }) {
                            menu(for: track)
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            Button(role: .destructive) {
                                remove(track)
                            } label: {
                                Label(removeLabel, systemImage: isVault ? "lock.open" : "minus.circle")
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.plain)
        .navigationTitle(title)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if let playlist = playlist {
                    Menu {
                        Button {
                            newName = playlist.name
                            renaming = true
                        } label: {
                            Label(L("Renommer"), systemImage: "pencil")
                        }
                        Button(role: .destructive) {
                            confirmDelete = true
                        } label: {
                            Label(L("Supprimer la playlist"), systemImage: "trash")
                        }
                    } label: {
                        CircleIcon(systemName: "ellipsis")
                    }
                }
            }
        }
        .alert(L("Renommer"), isPresented: $renaming) {
            TextField(L("Nom de la playlist"), text: $newName)
            Button(L("Annuler"), role: .cancel) {}
            Button(L("OK")) {
                if let playlist = playlist { model.renamePlaylist(playlist, to: newName) }
            }
        }
        .confirmationDialog(L("Supprimer la playlist ?"), isPresented: $confirmDelete, titleVisibility: .visible) {
            Button(L("Supprimer"), role: .destructive) {
                if let playlist = playlist {
                    model.deletePlaylist(playlist)
                    dismiss()
                }
            }
            Button(L("Annuler"), role: .cancel) {}
        } message: {
            Text(L("Les fichiers restent dans votre bibliothèque."))
        }
        .trackSheets(picking: $picking, deleting: $deleting)
        .quickLookPreview($previewURL, in: previewItems)
        .onDisappear {
            if isVault { model.lockVault() }
        }
    }

    private var emptyText: String {
        switch route {
        case .vault: return L("Rangez ici vos fichiers privés : ⋯ puis « Mettre au Coffre » dans la Bibliothèque.")
        case .favorites: return L("Touchez ⋯ puis « Favori » sur un fichier pour le retrouver ici.")
        default: return L("Ajoutez des téléchargements depuis la Bibliothèque : ⋯ puis « Ajouter à une playlist ».")
        }
    }

    private var removeLabel: String {
        isVault ? L("Sortir du Coffre") : L("Retirer")
    }

    @ViewBuilder
    private func menu(for track: Track) -> some View {
        if track.exists && !isVault {
            ShareLink(item: track.fileURL) {
                Label(L("Partager"), systemImage: "square.and.arrow.up")
            }
        }
        Button {
            remove(track)
        } label: {
            Label(removeLabel, systemImage: isVault ? "lock.open" : "minus.circle")
        }
        if isVault {
            Button(role: .destructive) {
                deleting = track
            } label: {
                Label(L("Supprimer"), systemImage: "trash")
            }
        }
    }

    private func open(_ track: Track, in list: [Track], at index: Int) {
        if track.isFolder {
            let photos = track.photoURLs
            guard let first = photos.first else { return }
            previewItems = photos
            previewURL = first
        } else {
            model.play(list, start: index)
        }
    }

    private func remove(_ track: Track) {
        switch route {
        case .favorites:
            model.toggleFavorite(track)
        case .vault:
            model.removeFromVault(track)
        case .playlist:
            if let playlist = playlist { model.remove(track, from: playlist) }
        default:
            break
        }
    }
}

/// Explorateur des fichiers de Nyx (comme l'app Fichiers).
struct FilesView: View {
    @EnvironmentObject var model: AppModel
    let path: String
    @State private var entries: [URL] = []
    @State private var previewURL: URL?

    private var title: String {
        path == PythonEngine.documentsURL.path ? L("Fichiers") : (path as NSString).lastPathComponent
    }

    var body: some View {
        List {
            if entries.isEmpty {
                EmptyState(icon: "folder", title: L("Dossier vide"))
                    .listRowSeparator(.hidden)
            } else {
                ForEach(entries, id: \.self) { url in
                    if isDirectory(url) {
                        NavigationLink(value: LibraryRoute.files(url.path)) {
                            fileRow(url, icon: "folder.fill", color: .blue,
                                    detail: L("{count} élément(s)", ["count": "\(count(url))"]))
                        }
                    } else {
                        Button {
                            open(url)
                        } label: {
                            fileRow(url, icon: icon(for: url), color: .brand, detail: Fmt.size(fileSize(url.path)))
                        }
                        .foregroundColor(.primary)
                        .swipeActions {
                            ShareLink(item: url) {
                                Label(L("Partager"), systemImage: "square.and.arrow.up")
                            }
                            .tint(.blue)
                        }
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(title)
        .onAppear(perform: reload)
        .refreshable {
            await MainActor.run { reload() }
        }
        .quickLookPreview($previewURL, in: entries.filter { !isDirectory($0) })
    }

    private func reload() {
        let base = URL(fileURLWithPath: path)
        let names = (try? FileManager.default.contentsOfDirectory(atPath: path)) ?? []
        let urls = names.filter { !$0.hasPrefix(".") }.map { base.appendingPathComponent($0) }
        entries = urls.sorted { lhs, rhs in
            let left = isDirectory(lhs)
            let right = isDirectory(rhs)
            if left != right { return left }
            return lhs.lastPathComponent.localizedCaseInsensitiveCompare(rhs.lastPathComponent) == .orderedAscending
        }
    }

    private func isDirectory(_ url: URL) -> Bool {
        var flag: ObjCBool = false
        return FileManager.default.fileExists(atPath: url.path, isDirectory: &flag) && flag.boolValue
    }

    private func count(_ url: URL) -> Int {
        ((try? FileManager.default.contentsOfDirectory(atPath: url.path)) ?? []).filter { !$0.hasPrefix(".") }.count
    }

    private func icon(for url: URL) -> String {
        let ext = url.pathExtension.lowercased()
        if videoExtensions.contains(ext) { return "film" }
        if audioExtensions.contains(ext) { return "music.note" }
        if imageExtensions.contains(ext) { return "photo" }
        return "doc"
    }

    private func open(_ url: URL) {
        let ext = url.pathExtension.lowercased()
        if videoExtensions.contains(ext) || audioExtensions.contains(ext) {
            model.playFile(url)
        } else {
            previewURL = url
        }
    }

    private func fileRow(_ url: URL, icon: String, color: Color, detail: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundColor(color)
                .frame(width: 30)
            VStack(alignment: .leading, spacing: 2) {
                Text(url.lastPathComponent)
                    .font(.system(size: 15))
                    .lineLimit(2)
                if !detail.isEmpty {
                    Text(detail)
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                }
            }
        }
    }
}

/// Le moteur Python n'a pas démarré : on affiche l'erreur exacte (une capture suffit pour corriger).
struct EngineErrorCard: View {
    let message: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(L("Le moteur de téléchargement n'a pas démarré"), systemImage: "exclamationmark.triangle.fill")
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(.orange)
            Text(L("Faites une capture de cet écran et envoyez-la : elle indique exactement ce qui bloque."))
                .font(.system(size: 13))
                .foregroundColor(.secondary)
            Text(message)
                .font(.system(size: 11, design: .monospaced))
                .foregroundColor(.secondary)
                .textSelection(.enabled)
                .lineLimit(14)
        }
        .padding(.vertical, 6)
    }
}
