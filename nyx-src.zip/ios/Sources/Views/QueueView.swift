import SwiftUI

/// Onglet File : chaque téléchargement en carte, avec son avancement et ses actions.
struct QueueView: View {
    @EnvironmentObject var model: AppModel

    private var summary: String {
        let active = model.jobs.filter { $0.active }.count
        let done = model.jobs.filter { $0.isDone }.count
        let failed = model.jobs.filter { $0.isFailed }.count
        return L("{active} en cours · {done} terminé(s) · {failed} échec(s)",
                 ["active": "\(active)", "done": "\(done)", "failed": "\(failed)"])
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 10) {
                    if model.jobs.isEmpty {
                        EmptyState(icon: "arrow.down.circle", title: L("Aucun téléchargement"),
                                   subtitle: L("Collez un lien dans l'onglet Télécharger, ou ouvrez une vidéo dans le Navigateur."))
                            .padding(.top, 40)
                    } else {
                        Text(summary)
                            .font(.system(size: 15))
                            .foregroundColor(.secondary)
                            .padding(.horizontal, 4)
                            .padding(.bottom, 6)
                        ForEach(model.jobs) { job in
                            JobCard(job: job)
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 24)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle(L("File d'attente"))
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button {
                            model.jobAction("pause_all")
                        } label: {
                            Label(L("Tout mettre en pause"), systemImage: "pause")
                        }
                        Button {
                            model.jobAction("resume_all")
                        } label: {
                            Label(L("Tout reprendre"), systemImage: "play")
                        }
                        Button(role: .destructive) {
                            model.jobAction("clear_finished")
                        } label: {
                            Label(L("Effacer les terminés"), systemImage: "trash")
                        }
                    } label: {
                        CircleIcon(systemName: "ellipsis")
                    }
                }
            }
        }
    }
}
