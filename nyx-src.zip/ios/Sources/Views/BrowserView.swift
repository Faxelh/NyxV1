import SwiftUI
import WebKit

struct BrowserSite: Identifiable, Hashable {
    let name: String
    let link: String
    var id: String { name }
}

let browserSites: [BrowserSite] = [
    BrowserSite(name: "TikTok", link: "https://www.tiktok.com/"),
    BrowserSite(name: "YouTube", link: "https://m.youtube.com/"),
    BrowserSite(name: "Facebook", link: "https://m.facebook.com/watch/"),
    BrowserSite(name: "Instagram", link: "https://www.instagram.com/"),
    BrowserSite(name: "X", link: "https://x.com/"),
]

/// Le lien ressemble-t-il à une vidéo (ou une publication) téléchargeable ?
func looksLikeVideo(_ link: String) -> Bool {
    let lower = link.lowercased()
    guard lower.hasPrefix("http") else { return false }
    let markers = ["/video/", "/photo/", "/reel/", "/reels/", "/videos/", "watch?v=", "/watch/", "youtu.be/",
                   "/shorts/", "/status/", "fb.watch", "/p/", "/tv/", "dailymotion.com/video", "vimeo.com/",
                   "/share/v/", "/share/r/", "story.php", "/playlist?list="]
    return markers.contains { lower.contains($0) }
}

/// Garde la page ouverte quand on change d'onglet, et transmet les
/// connexions (cookies) au moteur pour les contenus réservés aux abonnés.
final class BrowserModel: NSObject, ObservableObject, WKNavigationDelegate {
    let webView: WKWebView
    @Published var address = ""
    @Published private(set) var currentURL = ""
    @Published private(set) var canGoBack = false
    @Published private(set) var canGoForward = false
    @Published private(set) var loading = false
    @Published private(set) var progress: Double = 0
    private var observations: [NSKeyValueObservation] = []
    private var exportWork: DispatchWorkItem?

    static let touchFix = """
    (function () {
      try {
        if (document.getElementById('nyx-touch-fix')) return;
        var style = document.createElement('style');
        style.id = 'nyx-touch-fix';
        style.textContent = 'html, body, * { touch-action: pan-y !important; }';
        (document.head || document.documentElement).appendChild(style);
      } catch (e) {}
    })();
    """

    static let probe = """
    (function () {
      function meta(sel) { var e = document.querySelector(sel); return e ? (e.content || e.href || '') : ''; }
      return JSON.stringify({ href: location.href, og: meta('meta[property="og:url"]'),
                              canonical: meta('link[rel="canonical"]') });
    })()
    """

    override init() {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.websiteDataStore = .default()
        let script = WKUserScript(source: BrowserModel.touchFix, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        configuration.userContentController.addUserScript(script)
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.allowsBackForwardNavigationGestures = true
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 "
            + "(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
        super.init()
        webView.navigationDelegate = self
        observations = [
            webView.observe(\.url, options: [.new]) { [weak self] view, _ in
                DispatchQueue.main.async { self?.syncURL(view) }
            },
            webView.observe(\.estimatedProgress, options: [.new]) { [weak self] view, _ in
                DispatchQueue.main.async { self?.progress = view.estimatedProgress }
            },
            webView.observe(\.isLoading, options: [.new]) { [weak self] view, _ in
                DispatchQueue.main.async { self?.loading = view.isLoading }
            },
        ]
        let home = UserDefaults.standard.string(forKey: "homePage") ?? browserSites[0].link
        load(home)
    }

    private func syncURL(_ view: WKWebView) {
        let link = view.url?.absoluteString ?? ""
        if link != currentURL {
            currentURL = link
            if !link.isEmpty && !link.hasPrefix("about:") { address = link }
        }
        canGoBack = view.canGoBack
        canGoForward = view.canGoForward
    }

    func load(_ text: String) {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        var link = clean
        if !clean.lowercased().hasPrefix("http") {
            if clean.contains(".") && !clean.contains(" ") {
                link = "https://" + clean
            } else {
                let query = clean.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? clean
                link = "https://duckduckgo.com/?q=" + query
            }
        }
        guard let url = URL(string: link) else { return }
        address = link
        webView.load(URLRequest(url: url))
    }

    func goBack() { if webView.canGoBack { webView.goBack() } }
    func goForward() { if webView.canGoForward { webView.goForward() } }
    func reload() { webView.reload() }

    /// Meilleure adresse de vidéo pour la page affichée.
    func pageAddress(completion: @escaping (String) -> Void) {
        let fallback = webView.url?.absoluteString ?? ""
        webView.evaluateJavaScript(BrowserModel.probe) { result, _ in
            var candidates: [String] = []
            if let text = result as? String, let data = text.data(using: .utf8),
               let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                for key in ["href", "og", "canonical"] {
                    if let value = object[key] as? String, !value.isEmpty { candidates.append(value) }
                }
            }
            candidates.insert(fallback, at: min(1, candidates.count))
            let best = candidates.first(where: { looksLikeVideo($0) }) ?? candidates.first(where: { !$0.isEmpty }) ?? fallback
            completion(best)
        }
    }

    // MARK: WKNavigationDelegate

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        syncURL(webView)
        scheduleCookieExport()
    }

    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        syncURL(webView)
    }

    // MARK: Connexions -> moteur (cookies.txt)

    func scheduleCookieExport() {
        exportWork?.cancel()
        let work = DispatchWorkItem { [weak self] in self?.exportCookies() }
        exportWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: work)
    }

    func exportCookies() {
        let enabled = UserDefaults.standard.object(forKey: "useCookies") as? Bool ?? true
        guard enabled else { return }
        webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { cookies in
            var lines = ["# Netscape HTTP Cookie File", "# Exporté par Nyx", ""]
            for cookie in cookies {
                let domain = cookie.domain
                let flag = domain.hasPrefix(".") ? "TRUE" : "FALSE"
                let secure = cookie.isSecure ? "TRUE" : "FALSE"
                let expiry = Int(cookie.expiresDate?.timeIntervalSince1970 ?? 0)
                let name = cookie.name.replacingOccurrences(of: "\t", with: " ")
                let value = cookie.value.replacingOccurrences(of: "\t", with: " ")
                lines.append([domain, flag, cookie.path, secure, String(expiry), name, value].joined(separator: "\t"))
            }
            let text = lines.joined(separator: "\n") + "\n"
            let target = PythonEngine.dataURL.appendingPathComponent("cookies.txt")
            DispatchQueue.global(qos: .utility).async {
                try? text.write(to: target, atomically: true, encoding: .utf8)
            }
        }
    }
}

struct WebViewContainer: UIViewRepresentable {
    let webView: WKWebView

    func makeUIView(context: Context) -> WKWebView {
        webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

/// Onglet Navigateur : on navigue comme dans Safari, et le bouton envoie la vidéo affichée à Nyx.
struct BrowserView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var browser: BrowserModel
    @FocusState private var editing: Bool

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 6) {
                Button {
                    browser.goBack()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 18, weight: .semibold))
                        .frame(width: 34, height: 36)
                }
                .disabled(!browser.canGoBack)
                Button {
                    browser.goForward()
                } label: {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 18, weight: .semibold))
                        .frame(width: 34, height: 36)
                }
                .disabled(!browser.canGoForward)
                HStack(spacing: 6) {
                    Image(systemName: browser.currentURL.hasPrefix("https") ? "lock.fill" : "magnifyingglass")
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                    TextField(L("Adresse ou recherche"), text: $browser.address)
                        .keyboardType(.webSearch)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled(true)
                        .submitLabel(.go)
                        .focused($editing)
                        .onSubmit {
                            browser.load(browser.address)
                        }
                }
                .padding(.horizontal, 10)
                .frame(height: 36)
                .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(Color(.tertiarySystemFill)))
                Button {
                    browser.reload()
                } label: {
                    Image(systemName: browser.loading ? "xmark" : "arrow.clockwise")
                        .font(.system(size: 16, weight: .semibold))
                        .frame(width: 34, height: 36)
                }
            }
            .padding(.horizontal, 8)
            .padding(.top, 6)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(browserSites) { site in
                        Button(site.name) {
                            editing = false
                            browser.load(site.link)
                        }
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.primary)
                        .padding(.horizontal, 14)
                        .frame(height: 32)
                        .background(Capsule().fill(Color(.tertiarySystemFill)))
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
            }

            ZStack(alignment: .top) {
                WebViewContainer(webView: browser.webView)
                if browser.loading && browser.progress < 1 {
                    ProgressView(value: browser.progress)
                        .tint(.brand)
                }
            }

            VStack(spacing: 6) {
                Button {
                    downloadPage()
                } label: {
                    Label(looksLikeVideo(browser.currentURL) ? L("Télécharger cette vidéo")
                          : L("Chercher une vidéo sur cette page"), systemImage: "arrow.down.circle.fill")
                }
                .buttonStyle(PrimaryButtonStyle())
                Text(looksLikeVideo(browser.currentURL) ? L("Touchez pour l'envoyer à Nyx.")
                     : L("Ouvrez une vidéo, puis touchez ce bouton."))
                    .font(.system(size: 12))
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(.bar)
        }
    }

    private func downloadPage() {
        editing = false
        browser.pageAddress { link in
            guard link.lowercased().hasPrefix("http") else {
                model.show(L("Aucune page ouverte."), .warn)
                return
            }
            browser.exportCookies()
            model.openDownload(link, analyze: true)
        }
    }
}
