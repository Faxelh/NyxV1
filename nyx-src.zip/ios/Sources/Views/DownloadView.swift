import SwiftUI

/// Onglet Télécharger : coller un ou plusieurs liens, analyser, choisir
/// Vidéo / Audio et la qualité, lancer.
struct DownloadView: View {
    @EnvironmentObject var model: AppModel
    @FocusState private var editing: Bool

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    linkField
                    HStack(spacing: 8) {
                        actionButton(L("Coller"), icon: "doc.on.clipboard") {
                            editing = false
                            model.pasteLinks()
                        }
                        actionButton(L("Analyser"), icon: "sparkle.magnifyingglass") {
                            editing = false
                            model.analyzeLinks()
                        }
                        .disabled(model.analyzing)
                        actionButton(L("Effacer"), icon: "xmark.circle", tint: .secondary) {
                            editing = false
                            model.clearLinks()
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 22)

                    header(L("Format"))
                    Picker("", selection: $model.media) {
                        Text(L("Vidéo")).tag("video")
                        Text(L("Audio")).tag("audio")
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 18)

                    if model.media == "video" {
                        header(L("Qualité"))
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(model.qualities, id: \.self) { item in
                                    Button {
                                        model.quality = item
                                    } label: {
                                        Text(qualityLabel(item))
                                            .font(.system(size: 14, weight: .semibold))
                                            .foregroundColor(model.quality == item ? .white : .primary)
                                            .padding(.horizontal, 16)
                                            .frame(height: 34)
                                            .background(Capsule().fill(model.quality == item ? Color.brand
                                                                       : Color(.tertiarySystemFill)))
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(.horizontal, 16)
                        }
                        .padding(.bottom, 18)
                    }

                    if let message = model.analysisMessage {
                        HStack(alignment: .top, spacing: 8) {
                            if model.analyzing {
                                ProgressView()
                            } else {
                                Image(systemName: model.analysisIsError ? "exclamationmark.triangle.fill" : "info.circle")
                                    .foregroundColor(model.analysisIsError ? .orange : .secondary)
                            }
                            Text(message)
                                .font(.system(size: 14))
                                .foregroundColor(model.analysisIsError ? .primary : .secondary)
                        }
                        .padding(.horizontal, 20)
                        .padding(.bottom, 14)
                    }

                    if let info = model.analysis {
                        resultCard(info)
                    }

                    Button {
                        editing = false
                        model.startDownload()
                    } label: {
                        Label(model.startTitle, systemImage: "arrow.down.circle.fill")
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .padding(.horizontal, 16)

                    if let info = model.analysis, info.kind == "playlist", !info.entries.isEmpty {
                        Button {
                            model.startAll()
                        } label: {
                            Text(L("Tout télécharger ({count})", ["count": "\(info.entries.count)"]))
                        }
                        .buttonStyle(PrimaryButtonStyle(filled: false))
                        .padding(.horizontal, 16)
                        .padding(.top, 10)
                    }

                    HStack(spacing: 12) {
                        Tile(icon: "safari.fill", title: L("Navigateur")) {
                            model.tab = .browser
                        }
                        Tile(icon: "lock.fill", title: L("Coffre"), tint: .red) {
                            model.openVault()
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 26)

                    Text(L("Dans TikTok, YouTube, Instagram… touchez « Partager » puis « Copier le lien », revenez ici et touchez « Coller ». Ou ouvrez la vidéo dans l'onglet Navigateur."))
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 24)
                        .padding(.top, 16)
                        .padding(.bottom, 30)
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .background(Color(.systemGroupedBackground))
            .navigationTitle(L("Télécharger"))
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button(L("OK")) { editing = false }
                }
            }
        }
    }

    private var linkField: some View {
        ZStack(alignment: .topLeading) {
            TextEditor(text: $model.linkText)
                .focused($editing)
                .font(.system(size: 15))
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .scrollContentBackground(.hidden)
                .frame(height: 96)
                .padding(8)
            if model.linkText.isEmpty {
                Text(L("Collez ici un lien (ou plusieurs, un par ligne)"))
                    .font(.system(size: 15))
                    .foregroundColor(Color(.placeholderText))
                    .padding(.horizontal, 13)
                    .padding(.vertical, 16)
                    .allowsHitTesting(false)
            }
        }
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
        .padding(.horizontal, 16)
        .padding(.top, 4)
        .padding(.bottom, 12)
    }

    private func header(_ title: String) -> some View {
        Text(title.uppercased())
            .font(.system(size: 13))
            .foregroundColor(.secondary)
            .padding(.horizontal, 32)
            .padding(.bottom, 7)
    }

    private func actionButton(_ title: String, icon: String, tint: Color = .brand,
                              action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(tint)
                .frame(maxWidth: .infinity)
                .frame(height: 42)
                .background(RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(Color(.secondarySystemGroupedBackground)))
        }
        .buttonStyle(.plain)
    }

    private func resultCard(_ info: Analysis) -> some View {
        HStack(spacing: 12) {
            Artwork(url: info.thumbnail, seed: info.url,
                    icon: info.kind == "photo" ? "photo.on.rectangle.angled"
                        : (info.kind == "playlist" ? "list.bullet.rectangle" : "play.rectangle.fill"),
                    width: 104, height: 66, radius: 10)
            VStack(alignment: .leading, spacing: 4) {
                Text(info.title)
                    .font(.system(size: 16, weight: .semibold))
                    .lineLimit(3)
                Text(info.details)
                    .font(.system(size: 13))
                    .foregroundColor(.secondary)
                    .lineLimit(2)
            }
            Spacer(minLength: 0)
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
        .padding(.horizontal, 16)
        .padding(.bottom, 16)
    }
}
