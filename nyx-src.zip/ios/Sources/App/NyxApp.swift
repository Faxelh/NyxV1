import SwiftUI

@main
struct NyxApp: App {
    @StateObject private var model = AppModel()
    @StateObject private var browser = BrowserModel()
    @AppStorage("theme") private var theme = "system"
    @AppStorage("language") private var language = "system"
    @Environment(\.scenePhase) private var scenePhase

    init() {
        SelfTest.runIfRequested()
    }

    private var scheme: ColorScheme? {
        switch theme {
        case "light": return .light
        case "dark": return .dark
        default: return nil
        }
    }

    var body: some Scene {
        WindowGroup {
            let _ = Lang.apply(language)
            RootView()
                .environmentObject(model)
                .environmentObject(browser)
                .tint(.brand)
                .preferredColorScheme(scheme)
                .id(language)
                .onChange(of: scenePhase) { phase in
                    model.scenePhaseChanged(phase)
                    if phase == .background { browser.exportCookies() }
                }
                .onChange(of: language) { _ in
                    model.setEngineLanguage()
                }
                .onOpenURL { url in
                    model.openDownload(url.absoluteString, analyze: true)
                }
        }
    }
}

struct RootView: View {
    @EnvironmentObject var model: AppModel

    private var activeCount: Int {
        model.jobs.filter { $0.active }.count
    }

    var body: some View {
        TabView(selection: $model.tab) {
            BrowserView()
                .tabItem { Label(L("Navigateur"), systemImage: "safari") }
                .tag(AppTab.browser)
            DownloadView()
                .tabItem { Label(L("Télécharger"), systemImage: "arrow.down.circle") }
                .tag(AppTab.download)
            QueueView()
                .tabItem { Label(L("File"), systemImage: "list.bullet.rectangle") }
                .badge(activeCount)
                .tag(AppTab.queue)
            LibraryView()
                .tabItem { Label(L("Bibliothèque"), systemImage: "rectangle.stack.fill") }
                .tag(AppTab.library)
            SettingsView()
                .tabItem { Label(L("Réglages"), systemImage: "gearshape.fill") }
                .tag(AppTab.settings)
        }
        .overlay(alignment: .top) {
            if let toast = model.toast {
                ToastBanner(toast: toast)
                    .padding(.top, 4)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .onTapGesture {
                        withAnimation { model.toast = nil }
                    }
            }
        }
        .overlay {
            if model.appLocked {
                LockView()
                    .transition(.opacity)
            }
        }
        .onChange(of: model.tab) { tab in
            if tab != .library {
                model.lockVault()
            }
        }
    }
}

/// Écran de verrouillage (Face ID à l'ouverture).
struct LockView: View {
    @EnvironmentObject var model: AppModel

    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()
            VStack(spacing: 16) {
                Spacer()
                Image("Logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 96, height: 96)
                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                Text("Nyx")
                    .font(.system(size: 28, weight: .bold))
                Text(L("Nyx est verrouillée."))
                    .foregroundColor(.secondary)
                Button {
                    model.unlockApp()
                } label: {
                    Label(L("Déverrouiller"), systemImage: "faceid")
                }
                .buttonStyle(PrimaryButtonStyle())
                .padding(.horizontal, 60)
                .padding(.top, 12)
                Spacer()
            }
        }
    }
}
