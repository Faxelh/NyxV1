"""Traductions anglaises de l'interface de Nyx (texte français → anglais)."""

EN = {
    # Onglets et titres
    "Navigateur": "Browser",
    "Télécharger": "Download",
    "File": "Queue",
    "Bibliothèque": "Library",
    "Réglages": "Settings",
    "File d'attente": "Queue",
    "Coffre": "Vault",
    "Fichiers": "Files",
    "Playlists": "Playlists",
    "Téléchargements": "Downloads",
    "Général": "General",
    "Confidentialité": "Privacy",
    "Stockage": "Storage",
    "Aide": "Help",
    "À propos": "About",
    "Langue": "Language",
    "Thème": "Theme",
    "Moteur": "Engine",
    "Format": "Format",
    "Qualité": "Quality",

    # Communs
    "Tout": "All",
    "Vidéos": "Videos",
    "Vidéo": "Video",
    "Audio": "Audio",
    "Meilleure": "Best",
    "Rechercher": "Search",
    "Partager": "Share",
    "Supprimer": "Delete",
    "Retirer": "Remove",
    "Annuler": "Cancel",
    "Créer": "Create",
    "Effacer": "Clear",
    "Coller": "Paste",
    "Analyser": "Analyze",
    "Lire": "Play",
    "Tout lire": "Play all",
    "Aléatoire": "Shuffle",
    "Compresser": "Compress",
    "Mettre au Coffre": "Move to Vault",
    "Sortir du Coffre": "Remove from Vault",
    "Ajouter à une playlist": "Add to a playlist",
    "Nouvelle playlist": "New playlist",
    "Nom de la playlist": "Playlist name",
    "Nom de la nouvelle playlist": "New playlist name",
    "Ma playlist": "My playlist",
    "Afficher plus ({count})": "Show more ({count})",
    "{count} élément(s)": "{count} item(s)",
    "Écran indisponible": "Screen unavailable",
    "Réessayez dans un instant.": "Try again in a moment.",

    # Navigateur
    "Adresse ou recherche": "Address or search",
    "Télécharger cette vidéo": "Download this video",
    "Chercher une vidéo sur cette page": "Find a video on this page",
    "Ouvrez une vidéo, puis touchez ce bouton.": "Open a video, then tap this button.",
    "Aucune page ouverte.": "No page open.",

    # Télécharger
    "Collez ici un lien (ou plusieurs, un par ligne)": "Paste a link here (or several, one per line)",
    "Tout télécharger": "Download all",
    "Tout télécharger ({count})": "Download all ({count})",
    "Dans TikTok, YouTube, Instagram… touchez « Partager » puis « Copier le lien », revenez ici et touchez "
    "« Coller ». Ou ouvrez la vidéo dans l'onglet Navigateur.":
        "In TikTok, YouTube, Instagram… tap “Share” then “Copy link”, come back here and tap “Paste”. "
        "Or open the video in the Browser tab.",
    "Analyse en cours…": "Analyzing…",
    "{count} téléchargement(s) ajouté(s) à la file.": "{count} download(s) added to the queue.",
    "{count} vidéo(s) ajoutée(s) à la file.": "{count} video(s) added to the queue.",
    "Le presse-papiers est vide.": "The clipboard is empty.",
    "Le presse-papiers ne contient pas de lien.": "The clipboard doesn't contain a link.",
    "Collez d'abord un lien.": "Paste a link first.",
    "{count} liens : ils seront téléchargés avec les options choisies.":
        "{count} links: they'll be downloaded with the selected options.",
    "Télécharger les {count} liens": "Download the {count} links",
    "Playlist · {count} vidéo(s)": "Playlist · {count} video(s)",
    "Télécharger la 1re vidéo": "Download the first video",
    "{count} photo(s)": "{count} photo(s)",
    "avec musique": "with music",
    "Vidéo : les photos (et la musique). Audio : la musique seule.":
        "Video: the photos (and the music). Audio: the music only.",
    "Seul l'audio est disponible dans un format compatible.": "Only the audio is available in a compatible format.",
    "Aucun format compatible n'a été trouvé pour ce contenu.": "No compatible format was found for this content.",

    # File
    "{active} en cours · {done} terminé(s) · {failed} échec(s)": "{active} active · {done} done · {failed} failed",
    "affichage de {shown}/{total}": "showing {shown}/{total}",
    "reste {eta}": "{eta} left",
    "Pause": "Pause",
    "Reprendre": "Resume",
    "Retélécharger": "Download again",
    "Réessayer": "Try again",
    "Tout mettre en pause": "Pause all",
    "Tout reprendre": "Resume all",
    "Effacer les terminés": "Clear finished",
    "Aucun téléchargement": "No downloads",
    "Collez un lien dans l'onglet Télécharger, ou ouvrez une vidéo dans le Navigateur.":
        "Paste a link in the Download tab, or open a video in the Browser.",
    "En attente": "Queued",
    "Démarrage…": "Starting…",
    "Téléchargement…": "Downloading…",
    "Assemblage…": "Merging…",
    "En attente du réseau": "Waiting for network",
    "Nouvelle tentative…": "Retrying…",
    "Nouvelle tentative ({count})…": "Retrying ({count})…",
    "En pause": "Paused",
    "Terminé": "Done",
    "Échec": "Failed",
    "Annulé": "Cancelled",
    "Déjà téléchargé": "Already downloaded",

    # Bibliothèque
    "Supprimé ou déplacé": "Deleted or moved",
    "Historique effacé.": "History cleared.",
    "Ajoutez des téléchargements depuis la Bibliothèque : ⋯ puis « Ajouter à une playlist ».":
        "Add downloads from the Library: tap ⋯ then “Add to a playlist”.",
    "« {name} » créée.": "“{name}” created.",
    "« {name} » supprimée.": "“{name}” deleted.",
    "Rangez ici vos fichiers privés : ⋯ puis « Mettre au Coffre » dans la Bibliothèque.":
        "Keep your private files here: tap ⋯ then “Move to Vault” in the Library.",
    "Les fichiers du Coffre sont cachés de la Bibliothèque et de l'app Fichiers. "
    "Le Coffre se reverrouille dès que vous le quittez.":
        "Files in the Vault are hidden from the Library and from the Files app. "
        "The Vault locks again as soon as you leave it.",
    "Effacer l'historique": "Clear history",
    "La liste des téléchargements sera vidée. Les fichiers restent dans l'app Fichiers, "
    "les playlists et le Coffre ne changent pas.":
        "The download list will be emptied. Files stay in the Files app; playlists and the Vault "
        "don't change.",
    "Playlist introuvable": "Playlist not found",
    "Aucun élément": "No items",
    "Coffre verrouillé": "Vault locked",
    "Dossier vide": "Empty folder",
    "Aucun résultat": "No results",
    "Essayez avec d'autres mots.": "Try different words.",
    "Vos téléchargements apparaîtront ici.": "Your downloads will appear here.",
    "Supprimer le fichier": "Delete the file",
    "Retirer de la liste seulement": "Remove from the list only",
    "Retirer de la liste": "Remove from the list",
    "Ouvrir dans Fichiers": "Open in Files",
    "Vos fichiers sont dans l'app Fichiers › Sur mon iPhone › Nyx.": "Your files are in Files › On My iPhone › Nyx.",

    # Réglages
    "Automatique (système)": "Automatic (system)",
    "Clair": "Light",
    "Sombre": "Dark",
    "Langue du téléphone": "Phone language",
    "Simultanés": "Simultaneous",
    "Type par défaut": "Default type",
    "Qualité par défaut": "Default quality",
    "Audio (M4A)": "Audio (M4A)",
    "Vidéo (MP4)": "Video (MP4)",
    "Ajouter à l'app Photos": "Add to Photos",
    "Ignorer les doublons": "Skip duplicates",
    "Noms de fichiers propres": "Clean file names",
    "Nouvelles tentatives": "Automatic retries",
    "Écran toujours allumé": "Keep screen on",
    "Page d'accueil": "Home page",
    "Utiliser mes connexions": "Use my sign-ins",
    "Oublier les connexions": "Forget sign-ins",
    "Code Face ID": "Face ID passcode",
    "Moteur de téléchargement": "Download engine",
    "Partager Nyx": "Share Nyx",
    "Envoyer un avis": "Send feedback",
    "Connectez-vous à vos comptes dans l'onglet Navigateur : Nyx réutilise ces connexions pour les "
    "contenus réservés aux abonnés.":
        "Sign in to your accounts in the Browser tab: Nyx reuses those sign-ins for members-only content.",
    "Nyx télécharge uniquement les contenus publics, ou ceux auxquels vous avez légitimement accès. "
    "Respectez le droit d'auteur et les règles des plateformes.":
        "Nyx only downloads public content, or content you legitimately have access to. "
        "Respect copyright and each platform's rules.",
    "Fichiers de Nyx : {used}": "Nyx files: {used}",
    "Libre : {free}": "Free: {free}",
    "La nouvelle langue s'applique au prochain lancement de Nyx.":
        "The new language applies the next time you open Nyx.",
    "Langue enregistrée : fermez puis rouvrez Nyx pour l'appliquer.":
        "Language saved: close and reopen Nyx to apply it.",
    "Nombre de téléchargements en même temps. Plus, c'est plus rapide mais consomme davantage de batterie.":
        "Number of downloads at the same time. More is faster but uses more battery.",
    "Si la qualité choisie n'existe pas, Nyx prend la plus proche.":
        "If the chosen quality doesn't exist, Nyx picks the closest one.",
    "Nyx vous y emmène dans l'onglet Navigateur : connectez-vous si besoin.":
        "Nyx opens it in the Browser tab: sign in if needed.",
    "Verrouiller Nyx à l'ouverture": "Lock Nyx when opening",
    "Nyx demandera Face ID à chaque ouverture. Le Coffre est toujours protégé, même si cette option "
    "est désactivée.":
        "Nyx will ask for Face ID every time it opens. The Vault is always protected, even when this "
        "option is off.",
    "JavaScriptCore (iOS)": "JavaScriptCore (iOS)",
    "JavaScript (YouTube)": "JavaScript (YouTube)",
    "indisponible": "unavailable",
    "absent": "missing",
    "Le moteur est mis à jour à chaque nouvelle version de Nyx.": "The engine is updated with every new version of Nyx.",
    "Connexions oubliées par Nyx (celles du navigateur restent actives).":
        "Sign-ins forgotten by Nyx (the browser's own stay active).",
    "J'utilise Nyx pour garder mes vidéos et musiques hors ligne. Essayez-la !":
        "I use Nyx to keep my videos and music offline. Give it a try!",
    "Impossible d'ouvrir votre app de messagerie ici.": "Can't open your mail app here.",
    "Réglage non enregistré (stockage indisponible).": "Setting not saved (storage unavailable).",
    "Version {version}": "Version {version}",
    "Vos vidéos, musiques et photos, hors ligne.": "Your videos, music and photos, offline.",
    "par Faxel": "by Faxel",
    "Comment télécharger une vidéo ?": "How do I download a video?",
    "Dans TikTok, YouTube, Instagram…, touchez « Partager » puis « Copier le lien ». Revenez dans Nyx, "
    "onglet Télécharger, et touchez « Coller ». Vous pouvez aussi ouvrir la vidéo dans l'onglet "
    "Navigateur puis toucher « Télécharger cette vidéo ».":
        "In TikTok, YouTube, Instagram…, tap “Share” then “Copy link”. Come back to Nyx, Download tab, "
        "and tap “Paste”. You can also open the video in the Browser tab and tap “Download this video”.",
    "Où sont mes fichiers ?": "Where are my files?",
    "Dans l'app Fichiers › Sur mon iPhone › Nyx, et dans la Bibliothèque de Nyx. Les fichiers du Coffre "
    "n'y apparaissent pas.":
        "In Files › On My iPhone › Nyx, and in the Nyx Library. Files in the Vault don't appear there.",
    "Comment cacher un fichier ?": "How do I hide a file?",
    "Dans la Bibliothèque, touchez ⋯ puis « Mettre au Coffre ». Il n'apparaît plus que dans le Coffre, "
    "protégé par Face ID.":
        "In the Library, tap ⋯ then “Move to Vault”. It then only appears in the Vault, protected by Face ID.",
    "Comment réduire la taille d'un fichier ?": "How do I make a file smaller?",
    "Touchez ⋯ puis « Compresser ». Si le gain est trop faible, le fichier d'origine est gardé.":
        "Tap ⋯ then “Compress”. If the saving is too small, the original file is kept.",
    "Pourquoi un téléchargement échoue ?": "Why does a download fail?",
    "Le contenu est peut-être privé, supprimé, en direct ou protégé (DRM). Pour un contenu réservé aux "
    "abonnés, connectez-vous dans l'onglet Navigateur puis réessayez.":
        "The content may be private, deleted, live or protected (DRM). For members-only content, sign in "
        "in the Browser tab and try again.",

    # Verrouillage, démarrage
    "Déverrouiller": "Unlock",
    "Déverrouiller Nyx": "Unlock Nyx",
    "Nyx est verrouillée.": "Nyx is locked.",
    "Nyx n'a pas pu démarrer. Faites une capture de cet écran et envoyez-la : elle indique exactement "
    "ce qui bloque.":
        "Nyx couldn't start. Take a screenshot of this screen and send it: it shows exactly what went wrong.",
    "Reprendre ?": "Resume?",
    "{count} téléchargement(s) n'étaient pas terminés. Les reprendre maintenant ?":
        "{count} download(s) weren't finished. Resume them now?",

    # Messages
    "Fichier introuvable (supprimé ou déplacé).": "File not found (deleted or moved).",
    "Déjà dans « {name} ».": "Already in “{name}”.",
    "Ajouté à « {name} ».": "Added to “{name}”.",
    "Supprimé.": "Deleted.",
    "Ouvrir le Coffre de Nyx": "Open the Nyx Vault",
    "Rangé dans le Coffre.": "Moved to the Vault.",
    "Sorti du Coffre : de retour dans la bibliothèque.": "Out of the Vault: back in your library.",
    "Compression de « {title} »…": "Compressing “{title}”…",
    "Compressé : {size} (−{saved}).": "Compressed: {size} (−{saved}).",
    "Lecture impossible ici : ouvrez le fichier depuis l'app Fichiers.": "Can't play here: open the file from the Files app.",
    "Lecture impossible ici : ouvrez les fichiers depuis l'app Fichiers.":
        "Can't play here: open the files from the Files app.",
    "Playlist vide, ou fichiers introuvables.": "Empty playlist, or files not found.",
    "Partage indisponible sur cet appareil.": "Sharing isn't available on this device.",
    "Coffre verrouillé : identification refusée.": "Vault locked: identification failed.",
    "Déjà dans le Coffre.": "Already in the Vault.",
    "Rien à compresser dans un dossier de photos.": "Nothing to compress in a photo folder.",
    "Compression déjà en cours pour ce fichier.": "This file is already being compressed.",
    "La compression est disponible sur iPhone uniquement.": "Compression is only available on iPhone.",
    "Compression impossible pour ce fichier.": "This file can't be compressed.",
    "Ce fichier est déjà léger : rien à gagner.": "This file is already small: nothing to gain.",
    "Connexion rétablie : reprise des téléchargements.": "Back online: downloads are resuming.",
    "Pas de connexion internet : les téléchargements reprendront tout seuls.":
        "No internet connection: downloads will resume on their own.",
    "Les photos sont dans l'app Fichiers › Nyx.": "The photos are in Files › Nyx.",
    "Impossible de ranger ce fichier dans le Coffre.": "Couldn't move this file to the Vault.",
    "Compression impossible (stockage).": "Compression failed (storage).",
    "Terminé : {title}": "Done: {title}",
    "Échec : {title}": "Failed: {title}",
    "Le fichier n'a pas pu être supprimé.": "The file couldn't be deleted.",
    "Impossible de sortir ce fichier du Coffre.": "Couldn't take this file out of the Vault.",

    # Erreurs du moteur (core/errors.py)
    "Contenu en direct (live) : Nyx ne télécharge pas les directs en cours ou à venir. Réessayez quand "
    "la rediffusion sera disponible.":
        "Live content: Nyx doesn't download ongoing or upcoming live streams. Try again when the replay "
        "is available.",
    "Déjà téléchargé (fichier présent).": "Already downloaded (file present).",
    "Bloqué : aucune progression pendant trop longtemps.": "Stuck: no progress for too long.",
    "Annulé.": "Cancelled.",
    "En pause.": "Paused.",
    "Aucun format lisible sur iPhone n’est proposé pour ce contenu (la plateforme ne fournit que du "
    "WebM/VP9). Essayez le mode Audio ou une autre qualité.":
        "No iPhone-compatible format is offered for this content (the platform only provides WebM/VP9). "
        "Try Audio mode or another quality.",
    "Ce site livre la vidéo dans un format (MPEG-TS/HLS) que Nyx ne sait pas encore convertir sur téléphone.":
        "This site delivers the video in a format (MPEG-TS/HLS) that Nyx can't convert on a phone yet.",
    "Ce lien ne correspond pas à une vidéo prise en charge.": "This link isn't a supported video.",
    "Lien invalide.": "Invalid link.",
    "Contenu protégé par DRM : téléchargement impossible.": "DRM-protected content: can't be downloaded.",
    "Ce direct n’a pas encore commencé.": "This live stream hasn't started yet.",
    "YouTube n’a pas pu être déchiffré avec le moteur JavaScript du téléphone. Réessayez ; si ça persiste, "
    "mettez Nyx à jour.":
        "YouTube couldn't be decoded with the phone's JavaScript engine. Try again; if it keeps happening, "
        "update Nyx.",
    "YouTube demande de confirmer que vous n’êtes pas un robot. Attendez un peu, ou connectez-vous à "
    "YouTube dans l’onglet Navigateur puis réessayez.":
        "YouTube is asking to confirm you're not a robot. Wait a bit, or sign in to YouTube in the Browser "
        "tab and try again.",
    "Connexion requise pour ce contenu (restreint, sensible ou réservé aux comptes connectés). "
    "Connectez-vous au site dans l’onglet Navigateur si vous y avez accès.":
        "Sign-in required for this content (restricted, sensitive or members-only). Sign in to the site in "
        "the Browser tab if you have access.",
    "Vidéo privée : votre compte n’y a pas accès.": "Private video: your account doesn't have access.",
    "Vidéo soumise à une vérification d’âge. Connectez-vous au site dans l’onglet Navigateur si vous "
    "y êtes autorisé.":
        "Age-restricted video. Sign in to the site in the Browser tab if you're allowed to watch it.",
    "Contenu non disponible dans votre pays.": "Content not available in your country.",
    "Contenu introuvable ou supprimé (lien expiré ou incorrect).": "Content not found or deleted (expired or wrong link).",
    "La plateforme limite les requêtes (429). Nyx réessaiera dans un instant.":
        "The platform is rate-limiting requests (429). Nyx will try again in a moment.",
    "L’hébergeur a refusé l’accès (403). Désactivez un éventuel VPN, puis réessayez.":
        "The host refused access (403). Turn off any VPN, then try again.",
    "La plateforme rencontre un problème temporaire (erreur serveur).": "The platform has a temporary problem (server error).",
    "Ce site bloque les téléchargements hors navigateur pour ce contenu. Réessayez plus tard.":
        "This site blocks downloads outside the browser for this content. Try again later.",
    "Pas de connexion internet (adresse introuvable).": "No internet connection (address not found).",
    "Délai de connexion dépassé.": "Connection timed out.",
    "La connexion a été interrompue.": "The connection was interrupted.",
    "La qualité demandée n’existe pas pour cette vidéo. Choisissez « Meilleure ».":
        "The requested quality doesn't exist for this video. Choose “Best”.",
    "Stockage du téléphone plein : libérez de l’espace puis réessayez.": "Phone storage full: free up space and try again.",
    "Impossible d’écrire le fichier sur le téléphone.": "Couldn't write the file to the phone.",
    "Publication « photo » TikTok : lecture impossible pour le moment (TikTok a peut-être bloqué la "
    "demande). Réessayez plus tard.":
        "TikTok “photo” post: can't be read right now (TikTok may have blocked the request). Try again later.",
    "Erreur de certificat SSL : vérifiez la date et l’heure du téléphone.":
        "SSL certificate error: check the phone's date and time.",
}
